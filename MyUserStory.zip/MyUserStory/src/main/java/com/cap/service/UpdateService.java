package com.cap.service;

public class UpdateService implements IUpdateService{

}
