package com.cap.service;

public interface IUpdateService {

}
