package com.imlewis.repository;

import org.springframework.data.repository.CrudRepository;

import com.imlewis.model.Slider;

public interface SliderRepository extends CrudRepository<Slider, Long>{
	

}
